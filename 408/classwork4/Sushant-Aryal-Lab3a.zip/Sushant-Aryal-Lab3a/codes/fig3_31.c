/* 
Name: Sushant Aryal
Course: CSC 306 – Operating Systems
Date: 2025-09-14
Lab: Lab 3A (Figures 3.30–3.35)
File: fig3_31.c
*/

/**
 * Figure 3.31
 */
#include <stdio.h>
#include <unistd.h>

int main() {
    fork();
    fork();
    fork();
    return 0;
}
